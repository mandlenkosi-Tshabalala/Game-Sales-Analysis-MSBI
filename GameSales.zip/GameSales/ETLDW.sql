INSERT INTO GameSaleDW.dbo.DimGame (GameName,ReleaseYear)
SELECT Name,CAST(Year AS INT)
FROM GameSalesStaging.dbo.StagingSales


INSERT INTO GameSaleDW.dbo.DimGenre (GenreName)
SELECT Distinct Genre
FROM GameSalesStaging.dbo.StagingSales


INSERT INTO GameSaleDW.dbo.DimPlatform(PlatformName)
SELECT Distinct Platform
FROM GameSalesStaging.dbo.StagingSales


INSERT INTO GameSaleDW.dbo.DimPublisher(PublisherName)
SELECT Distinct Publisher
FROM GameSalesStaging.dbo.StagingSales



INSERT INTO GameSaleDW.dbo.DimRegion (RegionName)
VALUES
('North America'),
('Europe'),
('Japan'),
('Other'),
('Global')




INSERT INTO GameSaleDW.dbo.FactSales(RegionKey,PlatformKey,GenreKey,PublisherKey,GameKey,Sales,Rank)
SELECT Re.RegionKey,Pl.PlatformKey,Ge.GenreKey,Pu.PublisherKey,Ga.GameKey,SS.NA_Sales,SS.Rank
FROM GameSalesStaging.dbo.StagingSales as SS
INNER JOIN GameSaleDW.dbo.DimGame as GA ON GA.GameName = SS.Name
INNER JOIN GameSaleDW.dbo.DimPublisher as Pu ON Pu.PublisherName = SS.Publisher
INNER JOIN GameSaleDW.dbo.DimPlatform as Pl ON Pl.PlatformName = SS.Platform
INNER JOIN GameSaleDW.dbo.DimGenre as Ge ON Ge.GenreName = SS.Genre
INNER JOIN GameSaleDW.dbo.DimRegion as Re ON Re.RegionName = 'North America'



INSERT INTO GameSaleDW.dbo.FactSales(RegionKey,PlatformKey,GenreKey,PublisherKey,GameKey,Sales,Rank)
SELECT Re.RegionKey,Pl.PlatformKey,Ge.GenreKey,Pu.PublisherKey,Ga.GameKey,SS.EU_Sales,SS.Rank
FROM GameSalesStaging.dbo.StagingSales as SS
INNER JOIN GameSaleDW.dbo.DimGame as GA ON GA.GameName = SS.Name
INNER JOIN GameSaleDW.dbo.DimPublisher as Pu ON Pu.PublisherName = SS.Publisher
INNER JOIN GameSaleDW.dbo.DimPlatform as Pl ON Pl.PlatformName = SS.Platform
INNER JOIN GameSaleDW.dbo.DimGenre as Ge ON Ge.GenreName = SS.Genre
INNER JOIN GameSaleDW.dbo.DimRegion as Re ON Re.RegionName = 'Europe'


INSERT INTO GameSaleDW.dbo.FactSales(RegionKey,PlatformKey,GenreKey,PublisherKey,GameKey,Sales,Rank)
SELECT Re.RegionKey,Pl.PlatformKey,Ge.GenreKey,Pu.PublisherKey,Ga.GameKey,SS.JP_Sales,SS.Rank
FROM GameSalesStaging.dbo.StagingSales as SS
INNER JOIN GameSaleDW.dbo.DimGame as GA ON GA.GameName = SS.Name
INNER JOIN GameSaleDW.dbo.DimPublisher as Pu ON Pu.PublisherName = SS.Publisher
INNER JOIN GameSaleDW.dbo.DimPlatform as Pl ON Pl.PlatformName = SS.Platform
INNER JOIN GameSaleDW.dbo.DimGenre as Ge ON Ge.GenreName = SS.Genre
INNER JOIN GameSaleDW.dbo.DimRegion as Re ON Re.RegionName = 'Japan'




INSERT INTO GameSaleDW.dbo.FactSales(RegionKey,PlatformKey,GenreKey,PublisherKey,GameKey,Sales,Rank)
SELECT Re.RegionKey,Pl.PlatformKey,Ge.GenreKey,Pu.PublisherKey,Ga.GameKey,SS.Other_Sales,SS.Rank
FROM GameSalesStaging.dbo.StagingSales as SS
INNER JOIN GameSaleDW.dbo.DimGame as GA ON GA.GameName = SS.Name
INNER JOIN GameSaleDW.dbo.DimPublisher as Pu ON Pu.PublisherName = SS.Publisher
INNER JOIN GameSaleDW.dbo.DimPlatform as Pl ON Pl.PlatformName = SS.Platform
INNER JOIN GameSaleDW.dbo.DimGenre as Ge ON Ge.GenreName = SS.Genre
INNER JOIN GameSaleDW.dbo.DimRegion as Re ON Re.RegionName = 'Other'



INSERT INTO GameSaleDW.dbo.FactSales(RegionKey,PlatformKey,GenreKey,PublisherKey,GameKey,Sales,Rank)
SELECT Re.RegionKey,Pl.PlatformKey,Ge.GenreKey,Pu.PublisherKey,Ga.GameKey,SS.Global_Sales,SS.Rank
FROM GameSalesStaging.dbo.StagingSales as SS
INNER JOIN GameSaleDW.dbo.DimGame as GA ON GA.GameName = SS.Name
INNER JOIN GameSaleDW.dbo.DimPublisher as Pu ON Pu.PublisherName = SS.Publisher
INNER JOIN GameSaleDW.dbo.DimPlatform as Pl ON Pl.PlatformName = SS.Platform
INNER JOIN GameSaleDW.dbo.DimGenre as Ge ON Ge.GenreName = SS.Genre
INNER JOIN GameSaleDW.dbo.DimRegion as Re ON Re.RegionName = 'Global'










