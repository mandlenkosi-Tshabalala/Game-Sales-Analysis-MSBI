CREATE TABLE DimGenre (
GenreKey INT PRIMARY KEY IDENTITY NOT NULL,
GenreName VARCHAR(200) NOT NULL,
);

CREATE TABLE DimPublisher (
PublisherKey INT PRIMARY KEY IDENTITY NOT NULL,
PublisherName VARCHAR(100) NOT NULL,
);

CREATE TABLE DimRegion (
RegionKey INT PRIMARY KEY IDENTITY NOT NULL,
RegionName VARCHAR(100) NOT NULL,
);

INSERT INTO DimRegion (RegionName)
VALUES
('North America'),
('Europe'),
('Japan'),
('Other'),
('Global')

CREATE TABLE DimPlatform (
PlatformKey INT PRIMARY KEY IDENTITY NOT NULL,
PlatformName VARCHAR(100) NOT NULL,
);


CREATE TABLE DimGame (
GameKey INT PRIMARY KEY IDENTITY NOT NULL,
GameName VARCHAR(200) NOT NULL,
ReleaseYear INT,
);



CREATE TABLE FactSales (
SalesKey INT PRIMARY KEY IDENTITY NOT NULL,
RegionKey INT FOREIGN KEY REFERENCES DimRegion(RegionKey) NOT NULL,
PlatformKey INT FOREIGN KEY REFERENCES DimPlatform(PlatformKey) NOT NULL,
GenreKey INT FOREIGN KEY REFERENCES DimGenre(GenreKey) NOT NULL,
PublisherKey INT FOREIGN KEY REFERENCES DimPublisher(PublisherKey) NOT NULL,
GameKey INT FOREIGN KEY REFERENCES DimGame(GameKey) NOT NULL,
Sales Float NOT NULL,
Rank INT NOT NULL
);


drop table FactSales,DimGame,DimGenre,DimPlatform,DimPublisher,DimRegion



