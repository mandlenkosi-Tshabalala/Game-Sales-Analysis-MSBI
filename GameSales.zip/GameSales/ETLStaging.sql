INSERT INTO Game (GameName,ReleaseYear)
SELECT Name,CAST(Year AS INT)
FROM Sheet3


INSERT INTO Genre (GenreName)
SELECT Distinct Genre
FROM Sheet3


INSERT INTO Platform(PlatformName)
SELECT Distinct Platform
FROM Sheet3


INSERT INTO Publisher(PublisherName)
SELECT Distinct Publisher
FROM Sheet3



INSERT INTO Region (RegionName)
VALUES
('North America'),
('Europe'),
('Japan'),
('Other'),
('Global')




INSERT INTO Sales(RegionId,PlatformId,GenreId,PublisherId,GameId,Sales)
SELECT Re.RegionId,Pl.PlatformId,Ge.GenreId,Pu.PublisherId,Ga.GameId,Sh.NA_Sales
FROM Sheet3 as Sh
INNER JOIN Game as GA ON GA.GameName = Sh.Name
INNER JOIN Publisher as Pu ON Pu.PublisherName = Sh.Publisher
INNER JOIN Platform as Pl ON Pl.PlatformName = Sh.Platform
INNER JOIN Genre as Ge ON Ge.GenreName = Sh.Genre
INNER JOIN Region as Re ON Re.RegionName = 'North America'



INSERT INTO Sales(RegionId,PlatformId,GenreId,PublisherId,GameId,Sales)
SELECT Re.RegionId,Pl.PlatformId,Ge.GenreId,Pu.PublisherId,Ga.GameId,Sh.EU_Sales
FROM Sheet3 as Sh
INNER JOIN Game as GA ON GA.GameName = Sh.Name
INNER JOIN Publisher as Pu ON Pu.PublisherName = Sh.Publisher
INNER JOIN Platform as Pl ON Pl.PlatformName = Sh.Platform
INNER JOIN Genre as Ge ON Ge.GenreName = Sh.Genre
INNER JOIN Region as Re ON Re.RegionName = 'Europe'



INSERT INTO Sales(RegionId,PlatformId,GenreId,PublisherId,GameId,Sales)
SELECT Re.RegionId,Pl.PlatformId,Ge.GenreId,Pu.PublisherId,Ga.GameId,Sh.JP_Sales
FROM Sheet3 as Sh
INNER JOIN Game as GA ON GA.GameName = Sh.Name
INNER JOIN Publisher as Pu ON Pu.PublisherName = Sh.Publisher
INNER JOIN Platform as Pl ON Pl.PlatformName = Sh.Platform
INNER JOIN Genre as Ge ON Ge.GenreName = Sh.Genre
INNER JOIN Region as Re ON Re.RegionName = 'Japan'



INSERT INTO Sales(RegionId,PlatformId,GenreId,PublisherId,GameId,Sales)
SELECT Re.RegionId,Pl.PlatformId,Ge.GenreId,Pu.PublisherId,Ga.GameId,Sh.Other_Sales
FROM Sheet3 as Sh
INNER JOIN Game as GA ON GA.GameName = Sh.Name
INNER JOIN Publisher as Pu ON Pu.PublisherName = Sh.Publisher
INNER JOIN Platform as Pl ON Pl.PlatformName = Sh.Platform
INNER JOIN Genre as Ge ON Ge.GenreName = Sh.Genre
INNER JOIN Region as Re ON Re.RegionName = 'Other'



INSERT INTO Sales(RegionId,PlatformId,GenreId,PublisherId,GameId,Sales)
SELECT Re.RegionId,Pl.PlatformId,Ge.GenreId,Pu.PublisherId,Ga.GameId,Sh.Global_Sales
FROM Sheet3 as Sh
INNER JOIN Game as GA ON GA.GameName = Sh.Name
INNER JOIN Publisher as Pu ON Pu.PublisherName = Sh.Publisher
INNER JOIN Platform as Pl ON Pl.PlatformName = Sh.Platform
INNER JOIN Genre as Ge ON Ge.GenreName = Sh.Genre
INNER JOIN Region as Re ON Re.RegionName = 'Global'










